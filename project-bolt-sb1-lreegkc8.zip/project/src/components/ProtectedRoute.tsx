import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import LoadingSpinner from './LoadingSpinner';
import { useLocation } from 'react-router-dom';
import { supabase } from '../lib/supabase';

export default function ProtectedRoute() {
  const { user, loading, initialized } = useAuth();
  const location = useLocation();

  if (loading || !initialized) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // First check: Policy acceptance
  if (!user.policy_accepted && location.pathname !== '/policy') {
    return <Navigate to="/policy" replace />;
  }

  // Second check: HR training form
  if (user.policy_accepted && !user.hr_training_completed && location.pathname !== '/hr-training') {
    return <Navigate to="/hr-training" replace />;
  }

  return <Outlet />;
}
