import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Users, Settings, ScrollText, FileCheck } from 'lucide-react';
import UserProfile from './UserProfile';
import { useAuth } from '../contexts/AuthContext';

export default function Sidebar() {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const isBackOffice = user?.role === 'back_office';

  return (
    <nav className="nav-calligraphic-bg shadow-lg border-y border-[#ff6900] py-[1px]">
      <div className="max-w-7xl mx-auto px-2">
        <div className="flex items-center justify-between h-12">
          <NavLink
            to="/"
            className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
          >
            <Home className="w-4 h-4 mr-2" />
            Dashboard
          </NavLink>

          <NavLink
            to="/my-policies"
            className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
          >
            <FileCheck className="w-4 h-4 mr-2" />
            My Policies
          </NavLink>

          {(isAdmin || isBackOffice) && (
            <NavLink
              to="/module-management"
              className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
            >
              <Settings className="w-4 h-4 mr-2" />
              Module Management
            </NavLink>
          )}

          {isAdmin && (
            <NavLink
              to="/policy-management"
              className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
            >
              <ScrollText className="w-4 h-4 mr-2" />
              Policy Management
            </NavLink>
          )}

          {isAdmin && (
            <NavLink
              to="/user-management"
              className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
            >
              <Users className="w-4 h-4 mr-2" />
              User Management
            </NavLink>
          )}
          <div className="ml-2">
          <UserProfile />
          </div>
        </div>
      </div>
    </nav>
  );
}