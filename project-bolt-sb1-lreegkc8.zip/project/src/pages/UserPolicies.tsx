import React, { useState, useEffect } from 'react';
import { ScrollText, CheckCircle, Clock, ExternalLink, PlayCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import LoadingSpinner from '../components/LoadingSpinner';
import type { Policy, PolicyAcceptance } from '../types';

export default function UserPolicies() {
  const [policies, setPolicies] = useState<(Policy & { accepted_at?: string })[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      fetchPoliciesAndAcceptances();
    }
  }, [user]);

  const fetchPoliciesAndAcceptances = async () => {
    try {
      // Fetch all active policies
      const { data: policiesData, error: policiesError } = await supabase
        .from('policies')
        .select('*')
        .eq('is_active', true)
        .order('display_order');

      if (policiesError) throw policiesError;

      // Fetch user's acceptances
      const { data: acceptancesData, error: acceptancesError } = await supabase
        .from('policy_acceptances')
        .select('policy_id, accepted_at')
        .eq('user_id', user?.id);

      if (acceptancesError) throw acceptancesError;

      // Combine policies with acceptance data
      const combinedData = policiesData.map(policy => ({
        ...policy,
        accepted_at: acceptancesData?.find(a => a.policy_id === policy.id)?.accepted_at
      }));

      setPolicies(combinedData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch policies');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-orange-50 to-orange-100 rounded-lg p-6 mb-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">My Policies & Training</h1>
            <div className="h-1 w-20 bg-[#ff6900] rounded-full mt-2"></div>
          </div>
          <div className="flex items-center gap-2 bg-white/50 px-4 py-2 rounded-lg">
            <ScrollText className="w-5 h-5 text-[#ff6900]" />
            <span className="text-gray-700 font-medium">
              {policies.filter(p => p.accepted_at).length} of {policies.length} Accepted
            </span>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6 border boost-border">
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-2">HR Training Status</h2>
          <div className="flex items-center gap-2 text-gray-700 mb-4">
            <div className={`w-3 h-3 rounded-full ${user?.hr_training_completed ? 'bg-green-500' : 'bg-orange-500'}`} />
            {user?.hr_training_completed ? 'Training Completed' : 'Training Required'}
          </div>
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-gray-700">Required Training Videos:</h3>
            <ul className="space-y-2">
              <li>
                <a
                  href="https://www.youtube.com/watch?v=zytc1qJTq-8"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-[#ff6900] hover:text-orange-700 transition-colors"
                >
                  <PlayCircle className="w-4 h-4" />
                  <span>Ethics in Workplace</span>
                </a>
              </li>
              <li>
                <a
                  href="https://www.youtube.com/watch?v=OdmmdH-_X3o"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-[#ff6900] hover:text-orange-700 transition-colors"
                >
                  <PlayCircle className="w-4 h-4" />
                  <span>Sexual Harassment Awareness and Prevention</span>
                </a>
              </li>
              <li>
                <a
                  href="https://www.youtube.com/watch?v=vOwdlHUVBGE"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-[#ff6900] hover:text-orange-700 transition-colors"
                >
                  <PlayCircle className="w-4 h-4" />
                  <span>Diversity and Inclusion</span>
                </a>
              </li>
            </ul>
          </div>
          {!user?.hr_training_completed && (
            <a
              href="/hr-training"
              className="inline-block mt-4 px-4 py-2 boost-gradient text-white rounded-lg hover:opacity-90 transition-all duration-200"
            >
              Complete Training
            </a>
          )}
        </div>

        <div>
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Policy Acceptances</h2>
          <div className="space-y-4">
            {policies.map((policy) => (
              <div key={policy.id} className="border rounded-lg p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-grow">
                    <div className="flex items-center gap-2">
                      <h3 className="font-medium text-gray-900">{policy.title}</h3>
                      <span className={`px-2 py-0.5 text-xs rounded-full ${
                        policy.accepted_at
                          ? 'bg-green-100 text-green-700'
                          : 'bg-orange-100 text-orange-700'
                      }`}>
                        {policy.accepted_at ? 'Accepted' : 'Pending'}
                      </span>
                    </div>
                    {policy.description && (
                      <p className="text-sm text-gray-600 mt-1">{policy.description}</p>
                    )}
                    <div className="flex items-center gap-4 mt-2">
                      <button
                        onClick={() => window.open(policy.pdf_url, '_blank')}
                        className="inline-flex items-center gap-1 text-sm text-[#ff6900] hover:text-orange-700"
                      >
                        <ExternalLink className="w-4 h-4" />
                        View PDF
                      </button>
                      {policy.accepted_at && (
                        <span className="inline-flex items-center gap-1 text-sm text-gray-500">
                          <Clock className="w-4 h-4" />
                          Accepted on {new Date(policy.accepted_at).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                  </div>
                  {policy.accepted_at && (
                    <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}