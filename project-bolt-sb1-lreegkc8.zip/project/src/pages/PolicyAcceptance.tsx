import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { ScrollText, CheckCircle, Upload, AlertTriangle, ExternalLink } from 'lucide-react';
import type { Policy, PolicyAcceptance } from '../types';

export default function PolicyAcceptance() {
  const [policies, setPolicies] = useState<Policy[]>([]);
  const [acceptances, setAcceptances] = useState<Record<string, boolean>>({});
  const [pdfOpened, setPdfOpened] = useState<Record<string, boolean>>({});
  const [showRefresh, setShowRefresh] = useState<Record<string, boolean>>({});
  const [currentPolicyIndex, setCurrentPolicyIndex] = useState(0);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [allAccepted, setAllAccepted] = useState(false);
  const [allPdfsOpened, setAllPdfsOpened] = useState(false);
  const navigate = useNavigate();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  useEffect(() => {
    fetchPolicies();
    if (user) {
      fetchAcceptances();
    }
  }, [user]);

  const fetchPolicies = async () => {
    try {
      const { data, error } = await supabase
        .from('policies')
        .select('*')
        .eq('is_active', true)
        .order('display_order');
      
      if (error) throw error;
      setPolicies(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch policies');
    }
  };

  const fetchAcceptances = async () => {
    try {
      const { data, error } = await supabase
        .from('policy_acceptances')
        .select('policy_id')
        .eq('user_id', user?.id);
      
      if (error) throw error;
      
      const acceptanceMap = (data || []).reduce((acc, item) => ({
        ...acc,
        [item.policy_id]: true
      }), {});
      
      setAcceptances(acceptanceMap);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch acceptances');
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploading(true);
      setError(null);

      const fileName = `policy-${Date.now()}.pdf`;
      const { error: uploadError } = await supabase.storage
        .from('policy-docs')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: policyData, error: insertError } = await supabase
        .from('policies')
        .insert([{
          title: file.name.replace('.pdf', ''),
          pdf_url: `${supabase.storage.from('policy-docs').getPublicUrl(fileName).data.publicUrl}`,
          created_by: user?.id,
          display_order: policies.length
        }])
        .select()
        .single();

      if (insertError) throw insertError;
      
      setPolicies([...policies, policyData]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to upload policy PDF');
    } finally {
      setUploading(false);
    }
  };

  const canOpenPolicy = (index: number) => {
    if (index === 0) return true;
    const prevPolicy = policies[index - 1];
    return prevPolicy && acceptances[prevPolicy.id];
  };

  const openPdf = (policy: Policy) => {
    const policyIndex = policies.findIndex(p => p.id === policy.id);
    if (!canOpenPolicy(policyIndex)) {
      setError('Please accept the previous policy first');
      return;
    }
    
    window.open(policy.pdf_url, '_blank');
    handleAccept(policy);
    setPdfOpened(prev => ({
      ...prev,
      [policy.id]: true
    }));
    setShowRefresh(prev => ({
      ...prev,
      [policy.id]: true
    }));
  };

  useEffect(() => {
    // Check if all PDFs have been opened
    if (policies.length > 0) {
      const allOpened = policies.every(policy => pdfOpened[policy.id]);
      setAllPdfsOpened(allOpened);
    }
  }, [pdfOpened, policies]);

  const handleAccept = async (policy: Policy) => {
    try {
      setError(null);

      const policyIndex = policies.findIndex(p => p.id === policy.id);
      if (!canOpenPolicy(policyIndex)) {
        setError('Please accept the previous policy first');
        return;
      }

      // Skip if already accepted
      if (acceptances[policy.id]) {
        return;
      }

      // Validate acceptance order
      const { data: isValid, error: validationError } = await supabase
        .rpc('validate_policy_acceptance', {
          user_uuid: user?.id,
          policy_uuid: policy.id
        });

      if (validationError) throw validationError;

      if (!isValid) {
        setError('Policies must be accepted in order');
        return;
      }
      
      const { error } = await supabase
        .from('policy_acceptances')
        .insert([{
          user_id: user?.id,
          policy_id: policy.id
        }]);

      if (error) throw error;
      
      setAcceptances(prev => ({
        ...prev,
        [policy.id]: true
      }));
      
      // Check and update policy status
      const { data: allAccepted, error: checkError } = await supabase
        .rpc('check_and_update_policy_status', {
          user_uuid: user?.id
        });
      
      if (checkError) throw checkError;
      
      if (allAccepted) {
        setAllAccepted(true);
        window.location.href = '/hr-training';
        return;
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to accept policy');
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-lg max-w-2xl w-full p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-orange-100 rounded-lg flex-shrink-0">
            <ScrollText className="w-6 h-6 text-[#ff6900]" />
          </div>
          <div className="flex-grow">
            <h1 className="text-2xl font-bold text-gray-900">Company Policies</h1>
            <p className="text-sm text-gray-600 mt-1">
              Please review and accept all policies to continue
            </p>
            {isAdmin && (
              <div className="mt-2">
                <label className="relative inline-block">
                  <input
                    type="file"
                    accept=".pdf"
                    onChange={handleFileUpload}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  <span className="inline-flex items-center gap-2 px-3 py-1 text-sm text-[#ff6900] border border-[#ff6900] rounded-lg hover:bg-orange-50">
                    <Upload className="w-4 h-4" />
                    {uploading ? 'Uploading...' : 'Upload New Policy'}
                  </span>
                </label>
              </div>
            )}
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
            <AlertTriangle className="w-5 h-5 flex-shrink-0" />
            <p className="text-sm">{error}</p>
          </div>
        )}

        <div className="space-y-6">
          {policies.map((policy) => (
            <div key={policy.id} className="border rounded-lg p-4">
              {showRefresh[policy.id] && !acceptances[policy.id] && (
                <div className="mb-4 p-3 bg-orange-50 border border-orange-200 rounded-lg flex items-center gap-2 text-orange-700">
                  <AlertTriangle className="w-5 h-5 flex-shrink-0" />
                  <p className="text-sm">Please refresh the page to continue with the next policy</p>
                </div>
              )}
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h3 className="font-medium text-gray-900">{policy.title}</h3>
                  <p className="text-sm text-gray-500 mt-1">
                    {acceptances[policy.id] 
                      ? 'Accepted' 
                      : policies.indexOf(policy) === 0 || acceptances[policies[policies.indexOf(policy) - 1]?.id]
                        ? 'Will be automatically accepted when opened'
                        : 'Accept previous policy first'}
                  </p>
                  {policy.description && (
                    <p className="text-sm text-gray-600 mt-1">{policy.description}</p>
                  )}
                </div>
                <button
                  onClick={() => openPdf(policy)}
                  disabled={!canOpenPolicy(policies.indexOf(policy))}
                  className="flex-shrink-0 inline-flex items-center gap-2 px-3 py-1.5 text-white boost-gradient rounded-lg hover:opacity-90 transition-all duration-200"
                >
                  <ExternalLink className="w-4 h-4" />
                  {pdfOpened[policy.id] ? 'Open Again' : 'Open PDF'}
                </button>
              </div>
              {!canOpenPolicy(policies.indexOf(policy)) && (
                <div className="mt-4 pt-4 border-t">
                  <p className="text-sm text-orange-600 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4" />
                    Please accept the previous policy first
                  </p>
                </div>
              )}
              {acceptances[policy.id] && (
                <div className="mt-4 pt-4 border-t">
                  <p className="text-sm text-green-600 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    Policy accepted
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-6 pt-6 border-t">
          <div className="flex items-center justify-between text-sm text-gray-600">
            <p>Progress: {Object.keys(acceptances).length} of {policies.length} policies accepted</p>
            {allPdfsOpened && allAccepted && (
              <button
                onClick={() => navigate('/hr-training')}
                className="px-4 py-2 boost-gradient text-white rounded-lg hover:opacity-90 transition-all duration-200"
              >
                Next: HR Training
              </button>
            )}
            {policies.length > 0 && (
              <div className="h-2 w-32 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full boost-gradient"
                  style={{
                    width: `${(Object.keys(acceptances).length / policies.length) * 100}%`
                  }}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}