import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { ClipboardCheck, AlertTriangle, Phone, Mail } from 'lucide-react';

export default function HRTrainingForm() {
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const { user } = useAuth();
  const [submitting, setSubmitting] = useState<'accept' | 'decline' | null>(null);

  const handleSubmit = async (response: boolean) => {
    try {
      setSubmitting(response ? 'accept' : 'decline');
      setError(null);

      if (!response) {
        setError('You must acknowledge and accept the training requirements to continue');
        setSubmitting(null);
        return;
      }

      // First, call the RPC function to update the status
      const { data: updated, error: rpcError } = await supabase
        .rpc('update_hr_training_status', {
          user_uuid: user?.id,
          completed: true
        });

      if (rpcError) {
        throw rpcError;
      }

      if (updated) {
        window.location.href = '/';
        return;
      }
      throw new Error('Failed to update training status');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to submit acknowledgment');
      setSubmitting(null);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-lg max-w-3xl w-full p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-orange-100 rounded-lg">
            <ClipboardCheck className="w-6 h-6 text-[#ff6900]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">HR Training Acknowledgment Form</h1>
            <p className="text-sm text-gray-600 mt-1">
              Please review and acknowledge the completion of mandatory workplace training
            </p>
          </div>
        </div>

        {error && (
          <div className="mb-6 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
            <AlertTriangle className="w-5 h-5 flex-shrink-0" />
            <p className="text-sm">{error}</p>
          </div>
        )}

        <div className="space-y-6">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Completion of Workplace Training Programs
            </h2>
            <p className="text-gray-700 mb-4">
              This document serves as formal acknowledgment that the undersigned employee has successfully completed the following mandatory workplace training programs provided by RBFC:
            </p>
            <ul className="space-y-3 text-gray-700 ml-4">
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-[#ff6900] rounded-full flex-shrink-0"></span>
                <a
                  href="https://www.youtube.com/watch?v=zytc1qJTq-8"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#ff6900] hover:underline hover:text-orange-700 transition-colors"
                >
                  Ethics in Workplace
                </a>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-[#ff6900] rounded-full flex-shrink-0"></span>
                <a
                  href="https://www.youtube.com/watch?v=OdmmdH-_X3o"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#ff6900] hover:underline hover:text-orange-700 transition-colors"
                >
                  Sexual Harassment Awareness and Prevention
                </a>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-[#ff6900] rounded-full flex-shrink-0"></span>
                <a
                  href="https://www.youtube.com/watch?v=vOwdlHUVBGE"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#ff6900] hover:underline hover:text-orange-700 transition-colors"
                >
                  Diversity and Inclusion
                </a>
              </li>
            </ul>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Acknowledgment of Understanding
            </h2>
            <p className="text-gray-700">
              I confirm that I:
            </p>
            <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4 mt-2">
              <li>Actively participated in the training sessions listed above</li>
              <li>Understand the concepts, policies, and expectations covered during the training</li>
              <li>Am aware of my responsibility to uphold the principles and guidelines presented</li>
            </ul>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Behavioral Responsibility
            </h2>
            <p className="text-gray-700 space-y-2">
              I further acknowledge that while RBFC has equipped me with training and resources, I am solely responsible for my actions and behaviors in the workplace. RBFC is not liable for any misconduct or inappropriate actions that I may take that are in violation of company policies or applicable laws.
            </p>
            <p className="text-gray-700 mt-2">
              In the event of any behavioral issues, I understand that such actions may result in disciplinary measures, up to and including termination of employment, in accordance with RBFC's policies and applicable regulations.
            </p>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Support for Concerns
            </h2>
            <p className="text-gray-700 mb-4">
              If there are any concerns or questions regarding inappropriate behavior or workplace misconduct, I understand that I can reach out to RBFC's Human Resources representative, Bhumika Parikh, at:
            </p>
            <div className="space-y-2 ml-4">
              <div className="flex items-center gap-2 text-gray-700">
                <Phone className="w-4 h-4 text-[#ff6900]" />
                <span>412-540-0001</span>
              </div>
              <div className="flex items-center gap-2 text-gray-700">
                <Mail className="w-4 h-4 text-[#ff6900]" />
                <span>info@rbfc.us</span>
              </div>
            </div>
          </div>

          <div className="border-t pt-6 space-y-6">
            <div className="flex justify-between gap-4">
              <button
                onClick={() => handleSubmit(false)}
                type="button"
                disabled={submitting !== null}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors duration-200"
              >
                {submitting === 'decline' ? 'Declining...' : 'Decline'}
              </button>
              <button
                onClick={() => handleSubmit(true)}
                type="button"
                disabled={submitting !== null}
                className="flex-1 px-4 py-2 boost-gradient text-white rounded-lg hover:opacity-90 transition-all duration-200"
              >
                {submitting === 'accept' ? 'Submitting...' : 'I Acknowledge & Accept'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}