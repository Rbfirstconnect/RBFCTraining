import React, { useState, useEffect } from 'react';
import { ScrollText, Upload, AlertTriangle, Trash2, CheckCircle, ExternalLink, Edit } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import LoadingSpinner from '../components/LoadingSpinner';
import type { Policy } from '../types';

export default function PolicyManagement() {
  const [policies, setPolicies] = useState<Policy[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [editingPolicy, setEditingPolicy] = useState<Policy | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const { user } = useAuth();

  useEffect(() => {
    fetchPolicies();
  }, []);

  const fetchPolicies = async () => {
    try {
      const { data, error } = await supabase
        .from('policies')
        .select('*')
        .order('display_order');
      
      if (error) throw error;
      setPolicies(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch policies');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploading(true);
      setError(null);

      const fileName = `policy-${Date.now()}.pdf`;
      const { error: uploadError } = await supabase.storage
        .from('policy-docs')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: policyData, error: insertError } = await supabase
        .from('policies')
        .insert([{
          title: file.name.replace('.pdf', ''),
          pdf_url: `${supabase.storage.from('policy-docs').getPublicUrl(fileName).data.publicUrl}`,
          created_by: user?.id,
          display_order: policies.length
        }])
        .select()
        .single();

      if (insertError) throw insertError;
      
      setPolicies([...policies, policyData]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to upload policy PDF');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (policyId: string) => {
    try {
      const { error } = await supabase
        .from('policies')
        .delete()
        .eq('id', policyId);

      if (error) throw error;

      setPolicies(policies.filter(p => p.id !== policyId));
      setShowDeleteConfirm(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete policy');
    }
  };

  const togglePolicyStatus = async (policy: Policy) => {
    try {
      const { error } = await supabase
        .from('policies')
        .update({ is_active: !policy.is_active })
        .eq('id', policy.id);

      if (error) throw error;

      setPolicies(policies.map(p => 
        p.id === policy.id ? { ...p, is_active: !p.is_active } : p
      ));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update policy status');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-orange-50 to-orange-100 rounded-lg p-6 mb-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Policy Management</h1>
            <div className="h-1 w-20 bg-[#ff6900] rounded-full mt-2"></div>
          </div>
          <div className="flex items-center gap-2 bg-white/50 px-4 py-2 rounded-lg">
            <ScrollText className="w-5 h-5 text-[#ff6900]" />
            <span className="text-gray-700 font-medium">{policies.length} Policies</span>
          </div>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertTriangle className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm">{error}</p>
        </div>
      )}

      <div className="bg-white p-6 rounded-lg shadow-lg space-y-4 border boost-border">
        <div>
          <label className="relative inline-block">
            <input
              type="file"
              accept=".pdf"
              onChange={handleFileUpload}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <span className="inline-flex items-center gap-2 px-4 py-2 text-white boost-gradient rounded-lg hover:opacity-90">
              <Upload className="w-4 h-4" />
              {uploading ? 'Uploading...' : 'Upload New Policy'}
            </span>
          </label>
        </div>

        <div className="space-y-4">
          {policies.map((policy) => (
            <div key={policy.id} className="border rounded-lg p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-grow">
                  <div className="flex items-center gap-2">
                    <h3 className="font-medium text-gray-900">{policy.title}</h3>
                    <span className={`px-2 py-0.5 text-xs rounded-full ${
                      policy.is_active 
                        ? 'bg-green-100 text-green-700'
                        : 'bg-gray-100 text-gray-700'
                    }`}>
                      {policy.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                  {policy.description && (
                    <p className="text-sm text-gray-600 mt-1">{policy.description}</p>
                  )}
                  <div className="flex items-center gap-4 mt-2">
                    <button
                      onClick={() => window.open(policy.pdf_url, '_blank')}
                      className="inline-flex items-center gap-1 text-sm text-[#ff6900] hover:text-orange-700"
                    >
                      <ExternalLink className="w-4 h-4" />
                      View PDF
                    </button>
                    <button
                      onClick={() => togglePolicyStatus(policy)}
                      className={`inline-flex items-center gap-1 text-sm ${
                        policy.is_active
                          ? 'text-gray-600 hover:text-gray-800'
                          : 'text-green-600 hover:text-green-800'
                      }`}
                    >
                      <CheckCircle className="w-4 h-4" />
                      {policy.is_active ? 'Deactivate' : 'Activate'}
                    </button>
                    <button
                      onClick={() => setShowDeleteConfirm(policy.id)}
                      className="inline-flex items-center gap-1 text-sm text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="w-4 h-4" />
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <div className="flex items-center gap-3 text-red-600 mb-4">
              <AlertTriangle className="w-6 h-6" />
              <h3 className="text-lg font-medium">Delete Policy</h3>
            </div>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this policy? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => setShowDeleteConfirm(null)}
                className="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={() => showDeleteConfirm && handleDelete(showDeleteConfirm)}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}