import { createClient } from '@supabase/supabase-js';
import { type User } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Validate environment variables
if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing required Supabase environment variables. Please check your .env file.');
}

// Validate URL format
try {
  new URL(supabaseUrl);
} catch (error) {
  throw new Error(`Invalid Supabase URL format: ${supabaseUrl}`);
}

// Initialize Supabase client with additional options and retry configuration
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    detectSessionInUrl: true,
    autoRefreshToken: true,
    storageKey: 'sb-auth-token',
    storage: {
      getItem: (key) => {
        try {
          const item = localStorage.getItem(key);
          return item ? JSON.parse(item) : null;
        } catch {
          return null;
        }
      },
      setItem: (key, value) => {
        try {
          localStorage.setItem(key, JSON.stringify(value));
        } catch {}
      },
      removeItem: (key) => {
        try {
          localStorage.removeItem(key);
        } catch {}
      }
    },
    debug: import.meta.env.DEV // Enable debug logs in development
  },
  global: {
    headers: {
      'X-Client-Info': 'supabase-js-web'
    }
  },
  db: {
    schema: 'public'
  },
  realtime: {
    params: {
      eventsPerSecond: 2
    }
  },
  // Enhanced fetch configuration with better error handling
  fetch: (url, options = {}) => {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout

    return fetch(url, {
      ...options,
      signal: controller.signal,
      credentials: 'include',
      headers: {
        ...options.headers,
        'Accept': 'application/json',
        'Cache-Control': 'no-cache'
      }
    })
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return response;
    })
    .catch(error => {
      if (error.name === 'AbortError') {
        throw new Error('Request timed out after 30 seconds');
      }
      console.error('Fetch error:', {
        url,
        error: error.message,
        stack: error.stack
      });
      throw error;
    })
    .finally(() => {
      clearTimeout(timeoutId);
    });
  }
});

// Test the connection and log detailed errors
(async () => {
  if (import.meta.env.DEV) {
    try {
      const { error } = await supabase.from('users').select('count').limit(1);
      if (error) {
        console.error('Supabase connection test failed:', {
          message: error.message,
          details: error.details,
          hint: error.hint,
          code: error.code
        });
      } else {
        console.log('Supabase connection test successful');
      }
    } catch (err) {
      console.error('Failed to initialize Supabase client:', err);
      if (err instanceof Error) {
        console.error({
          name: err.name,
          message: err.message,
          stack: err.stack
        });
      }
    }
  }
})();