import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import ModuleManagement from './pages/ModuleManagement';
import UserManagement from './pages/UserManagement';
import Login from './pages/Login';
import ModuleList from './pages/ModuleList';
import ModuleView from './pages/ModuleView.tsx';
import ProtectedRoute from './components/ProtectedRoute';
import PolicyAcceptance from './pages/PolicyAcceptance';
import UserPolicies from './pages/UserPolicies';
import HRTrainingForm from './pages/HRTrainingForm';
import PolicyManagement from './pages/PolicyManagement';

function AppContent() {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col relative calligraphic-bg overflow-x-hidden">
      <header className="w-full boost-gradient py-2 px-4 flex items-center justify-between fixed top-0 left-0 right-0 z-50 header-pattern">
        <h1 className="text-lg font-bold text-white">RB FIRST CONNECT</h1>
      </header>
      <div className="pt-2">
        <Sidebar />
      </div>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route element={<ProtectedRoute />}>
          <Route path="/policy" element={<PolicyAcceptance />} />
          <Route path="/hr-training" element={<HRTrainingForm />} />
          <Route path="/my-policies" element={
            <div className="px-4 md:px-8 py-4 mb-16">
              <UserPolicies />
            </div>
          } />
          <Route path="/" element={
            <div className="px-4 md:px-8 py-4 mb-16">
              <Dashboard />
            </div>
          } />
          <Route path="/folders/:folderId" element={
            <div className="px-4 md:px-8 py-4 mb-16">
              <ModuleList />
            </div>
          } />
          <Route path="/modules/:moduleId" element={
            <div className="px-4 md:px-8 py-4 mb-16">
              <ModuleView />
            </div>
          } />
          <Route path="/module-management" element={
            <div className="px-4 md:px-8 py-4 mb-16">
              <ModuleManagement />
            </div>
          } />
          <Route path="/policy-management" element={
            <div className="px-4 md:px-8 py-4 mb-16">
              <PolicyManagement />
            </div>
          } />
          <Route path="/user-management" element={
            <div className="px-4 md:px-8 py-4 mb-16">
              <UserManagement />
            </div>
          } />
        </Route>
      </Routes>
      <footer className="fixed bottom-0 left-0 right-0 boost-gradient py-2 text-center footer-pattern">
        <p className="text-sm text-white">© {new Date().getFullYear()} RB FIRST CONNECT. All rights reserved.</p>
        <p className="text-[10px] text-white/80">Powered by PARTH</p>
      </footer>
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;