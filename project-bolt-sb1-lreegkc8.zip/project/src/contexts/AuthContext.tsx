import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import { supabase } from '../lib/supabase';
import type { User } from '../types';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';

// Constants for session management
const MAX_RETRIES = 3;
const RETRY_DELAY = 1000; // 1 second
const REFRESH_COOLDOWN = 5000; // 5 seconds
const RECONNECT_DELAY = 2000; // 2 seconds
const TOKEN_REFRESH_MARGIN = 60000; // Refresh token 1 minute before expiration
const HEARTBEAT_INTERVAL = 30000; // Check session every 30 seconds
const REFRESH_EVENTS = ['visibilitychange', 'focus', 'online'];

interface AuthContextType {
  user: User | null;
  loading: boolean;
  initialized: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  refreshSession: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [initialized, setInitialized] = useState(false);
  const refreshingRef = useRef(false);
  const lastRefreshRef = useRef(Date.now());
  const heartbeatIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const refreshTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const reconnectTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const mountedRef = useRef(true);
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();

  // Function to check if browser is online
  const isOnline = () => typeof navigator !== 'undefined' && navigator.onLine;

  const startHeartbeat = () => {
    if (heartbeatIntervalRef.current) {
      clearInterval(heartbeatIntervalRef.current);
    }

    heartbeatIntervalRef.current = setInterval(async () => {
      if (!isOnline()) {
        console.log('Browser is offline, skipping heartbeat');
        return;
      }

      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        if (error) throw error;

        if (!session) {
          console.log('No session found during heartbeat, refreshing...');
          await refreshSession(MAX_RETRIES);
        } else if (session.expires_at) {
          const expiresAt = session.expires_at * 1000;
          const now = Date.now();
          
          if (expiresAt - now < TOKEN_REFRESH_MARGIN * 2) {
            console.log('Session expiring soon, refreshing...');
            await refreshSession(MAX_RETRIES);
          }
        }
      } catch (error) {
        console.error('Heartbeat check failed:', error);
        handleConnectionError();
      }
    }, HEARTBEAT_INTERVAL);
  };

  const setupRefreshTimer = (expiresAt: number) => {
    if (refreshTimerRef.current) {
      clearTimeout(refreshTimerRef.current);
    }

    const timeUntilRefresh = expiresAt - Date.now() - TOKEN_REFRESH_MARGIN;
    if (timeUntilRefresh > 0) {
      refreshTimerRef.current = setTimeout(() => {
        refreshSession(MAX_RETRIES);
      }, timeUntilRefresh);
    } else {
      // If token is already close to expiration, refresh immediately
      refreshSession(MAX_RETRIES);
    }
  };

  const setUserSafely = (newUser: User | null) => {
    if (!mountedRef.current) return;
    setUser(prev => {
      if (JSON.stringify(prev) === JSON.stringify(newUser)) return prev;
      return newUser;
    });
  };

  const handleAuthError = async (error: any) => {
    if (error?.message?.includes('Invalid Refresh Token') ||
        error?.message?.includes('refresh_token_not_found')) {
      console.log('Auth error detected, signing out...');
      await signOut(true);
    }
  };

  const handleConnectionError = async () => {
    console.log('Connection error detected, attempting to reconnect...');
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    
    reconnectTimeoutRef.current = setTimeout(async () => {
      try {
        if (isOnline()) {
          await refreshSession(MAX_RETRIES);
        } else {
          console.log('Still offline, will retry when online');
        }
      } catch (error) {
        console.error('Reconnection attempt failed:', error);
      }
    }, RECONNECT_DELAY);
  };

  useEffect(() => {
    mountedRef.current = true;

    async function checkSession() {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        if (error) {
          console.error('Session check error:', error);
          throw error;
        }

        if (!session) {
          handleConnectionError();
          return;
        }

        // Setup refresh timer based on session expiration
        if (session.expires_at) {
          setupRefreshTimer(session.expires_at * 1000);
          startHeartbeat();
        }

        if (session?.user && mountedRef.current) {
          await fetchUserData(session.user.id);
        } else {
          if (mountedRef.current) {
            setUser(null);
          }
        }
      } catch (error) {
        console.error('Session check error:', error);
        handleAuthError(error);
      } finally {
        if (mountedRef.current) {
          setInitialized(true);
          setLoading(false);
        }
      }
    }

    checkSession();

    return () => {
      mountedRef.current = false;
    };
  }, []);

  useEffect(() => {
    if (!initialized) {
      return;
    }

    if (!user && location.pathname !== '/login') {
      navigate('/login');
    } else if (user && location.pathname === '/login') {
      navigate('/');
    } else if (user && location.pathname === '/login' && initialized) {
      navigate('/');
    }
  }, [user, location.pathname, initialized]);

  useEffect(() => {
    if (!initialized) {
      return;
    }

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('Auth state changed:', event);

      if (event === 'SIGNED_OUT') {
        setUserSafely(null);
        if (refreshTimerRef.current) {
          window.clearTimeout(refreshTimerRef.current);
        }
        return;
      }

      if (event === 'SIGNED_IN' && session?.user) {
        try {
          await fetchUserData(session.user.id);
          if (session.expires_at) {
            setupRefreshTimer(session.expires_at * 1000);
            startHeartbeat();
          }
        } catch (error) {
          console.error('Error fetching user data after sign in:', error);
          setUserSafely(null);
          handleAuthError(error);
        }
      } else if (!session) {
        setUserSafely(null);
      }
    });

    return () => subscription.unsubscribe();
  }, [initialized]);

  const refreshSession = async (retries = MAX_RETRIES): Promise<void> => {
    if (refreshingRef.current) return;
    if (!isOnline()) {
      console.log('Browser is offline, skipping session refresh');
      return;
    }
    
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }

    try {
      refreshingRef.current = true;
      console.log('Refreshing session...');
      lastRefreshRef.current = Date.now();
      
      const { data: { session }, error } = await supabase.auth.getSession();
      
      if (error) throw error;
      
      if (session?.user) {
        await fetchUserData(session.user.id);
        console.log('Session refreshed successfully');
        
        if (session.expires_at) {
          setupRefreshTimer(session.expires_at * 1000);
          startHeartbeat();
        }
        
        window.dispatchEvent(new CustomEvent('sessionRefreshed'));
      } else {
        handleConnectionError();
        setUserSafely(null);
        if (location.pathname !== '/login') {
          navigate('/login', { replace: true });
        }
      }
    } catch (error) {
      console.error(`Session refresh attempt failed. Retries left: ${retries}`, error);
      
      if (retries > 0) {
        setTimeout(() => {
          const retryTimeout = setTimeout(() => {
            refreshSession(retries - 1);
            clearTimeout(retryTimeout);
          }, RETRY_DELAY);
        }, RETRY_DELAY);
      } else {
        console.error('Session refresh failed after all retries');
        setUserSafely(null);
        if (location.pathname !== '/login') {
          navigate('/login', { replace: true });
        }
      }
    } finally {
      refreshingRef.current = false;
    }
  };

  useEffect(() => {
    const handleRefreshEvent = async (event: string) => {
      if (
        (event === 'visibilitychange' && document.visibilityState === 'visible') ||
        (event === 'focus') ||
        (event === 'online' && isOnline())
      ) {
        console.log('Tab became visible, checking session...');
        const now = Date.now();
        if ((now - lastRefreshRef.current > REFRESH_COOLDOWN) && !refreshingRef.current) {
          lastRefreshRef.current = Date.now();
          await refreshSession(MAX_RETRIES);
        }
      }
    };

    // Add event listeners for refresh events
    REFRESH_EVENTS.forEach(event => {
      const target = event === 'visibilitychange' ? document : window;
      target.addEventListener(event, () => handleRefreshEvent(event));
    });

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = null;
      }
      if (refreshTimerRef.current) {
        clearTimeout(refreshTimerRef.current);
        refreshTimerRef.current = null;
      }
      if (heartbeatIntervalRef.current) {
        clearInterval(heartbeatIntervalRef.current);
        heartbeatIntervalRef.current = null;
      }

      REFRESH_EVENTS.forEach(event => {
        const target = event === 'visibilitychange' ? document : window;
        target.removeEventListener(event, () => handleRefreshEvent(event));
      });
    };
  }, [location.pathname]);

  async function fetchUserData(userId: string) {
    if (!mountedRef.current) return;

    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (error) {
        console.error('Error fetching user data:', error);
        setUserSafely(null);
        return;
      }

      if (!data) {
        setUserSafely(null);
        return;
      }

      setUserSafely(data);
    } catch (error) {
      console.error('Error in fetchUserData:', error);
      setUserSafely(null);
    } finally {
      if (mountedRef.current) {
        setLoading(false);
      }
    }
  }

  async function signIn(email: string, password: string) {
    setLoading(true);
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) {
      handleAuthError(error);
      setLoading(false);
      throw error;
    }

    try {
      if (data.user) {
        await fetchUserData(data.user.id);
        if (location.pathname === '/login') {
          navigate('/', { replace: true });
        }
      }
    } catch (error) {
      console.error('Error fetching user data after sign in:', error);
      setLoading(false);
      throw new Error('Failed to fetch user data after sign in');
    }
  }

  async function signOut(silent = false) {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;

      setUser(null);
      if (!silent && location.pathname !== '/login') {
        navigate('/login');
      }
    } catch (error) {
      console.error('Error signing out:', error);
      setUser(null);
      if (!silent && location.pathname !== '/login') {
        navigate('/login');
      }
    }
  }

  const value: AuthContextType = {
    user,
    loading,
    initialized,
    signIn,
    signOut,
    refreshSession
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}