/*
  # Fix storage bucket RLS policies

  1. Changes
    - Drop existing storage policies that may be conflicting
    - Create new policies with proper role checks using public.users table
    - Ensure admin users can manage files
    - Allow authenticated users to read files
    
  2. Security
    - Maintain secure access control
    - Use proper role checks against public.users table
*/

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Allow public read access" ON storage.objects;
DROP POLICY IF EXISTS "Allow admin users to upload files" ON storage.objects;
DROP POLICY IF EXISTS "Allow admin users to update files" ON storage.objects;
DROP POLICY IF EXISTS "Allow admin users to delete files" ON storage.objects;

-- Create bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
SELECT 'policy-docs', 'policy-docs', true
WHERE NOT EXISTS (
  SELECT 1 FROM storage.buckets WHERE id = 'policy-docs'
);

-- Allow authenticated users to read files
CREATE POLICY "Allow authenticated users to read policy files"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'policy-docs');

-- Allow admins to insert files
CREATE POLICY "Allow admins to upload policy files"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'policy-docs'
  AND EXISTS (
    SELECT 1 FROM public.users
    WHERE users.id = auth.uid()
    AND users.role = 'admin'
  )
);

-- Allow admins to update files
CREATE POLICY "Allow admins to update policy files"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'policy-docs'
  AND EXISTS (
    SELECT 1 FROM public.users
    WHERE users.id = auth.uid()
    AND users.role = 'admin'
  )
)
WITH CHECK (
  bucket_id = 'policy-docs'
  AND EXISTS (
    SELECT 1 FROM public.users
    WHERE users.id = auth.uid()
    AND users.role = 'admin'
  )
);

-- Allow admins to delete files
CREATE POLICY "Allow admins to delete policy files"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'policy-docs'
  AND EXISTS (
    SELECT 1 FROM public.users
    WHERE users.id = auth.uid()
    AND users.role = 'admin'
  )
);