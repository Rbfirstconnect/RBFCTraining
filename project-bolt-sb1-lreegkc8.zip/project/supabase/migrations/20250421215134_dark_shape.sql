/*
  # Add RPC function for updating HR training status
  
  1. Changes
    - Add function to update HR training status
    - Add proper error handling and validation
    - Return success status
*/

-- Create function to update HR training status
CREATE OR REPLACE FUNCTION update_hr_training_status(
  user_uuid UUID,
  completed BOOLEAN
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Validate user exists
  IF NOT EXISTS (SELECT 1 FROM users WHERE id = user_uuid) THEN
    RAISE EXCEPTION 'User not found';
  END IF;

  -- Update user's training status
  UPDATE users
  SET 
    hr_training_completed = completed,
    updated_at = NOW()
  WHERE id = user_uuid;

  RETURN FOUND;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION update_hr_training_status TO authenticated;