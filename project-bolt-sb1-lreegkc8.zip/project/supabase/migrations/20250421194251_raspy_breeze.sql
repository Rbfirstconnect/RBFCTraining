/*
  # Add function to update user policy status

  1. Changes
    - Add RPC function to update user policy status
    - Ensure proper error handling
    - Return success status
*/

CREATE OR REPLACE FUNCTION update_user_policy_status(user_id UUID, accepted BOOLEAN)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE users
  SET 
    policy_accepted = accepted,
    policy_updated_at = NOW()
  WHERE id = user_id;
  
  RETURN FOUND;
END;
$$;