/*
  # Add policies table and relationships
  
  1. New Tables
    - `policies`: Stores company policy documents
    - Track policy versions and acceptance

  2. Changes
    - Add policies table
    - Add policy_acceptances table for tracking user acceptance
    - Update existing policy columns
*/

-- Create policies table
CREATE TABLE policies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  pdf_url TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  created_by UUID REFERENCES users(id),
  updated_at TIMESTAMPTZ DEFAULT now(),
  updated_by UUID REFERENCES users(id),
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true
);

-- Create policy_acceptances table
CREATE TABLE policy_acceptances (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  policy_id UUID REFERENCES policies(id) ON DELETE CASCADE,
  accepted_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, policy_id)
);

-- Enable RLS
ALTER TABLE policies ENABLE ROW LEVEL SECURITY;
ALTER TABLE policy_acceptances ENABLE ROW LEVEL SECURITY;

-- Policies for policies table
CREATE POLICY "Allow public read access to policies"
ON policies FOR SELECT
TO public
USING (is_active = true);

CREATE POLICY "Allow admins to manage policies"
ON policies FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.role = 'admin'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.role = 'admin'
  )
);

-- Policies for policy_acceptances table
CREATE POLICY "Users can view their own acceptances"
ON policy_acceptances FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "Users can accept policies"
ON policy_acceptances FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

-- Add trigger for updated_at
CREATE TRIGGER update_policies_updated_at
  BEFORE UPDATE ON policies
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Function to check if user has accepted all policies
CREATE OR REPLACE FUNCTION has_accepted_all_policies(user_uuid UUID)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN NOT EXISTS (
    SELECT 1 FROM policies p
    WHERE p.is_active = true
    AND NOT EXISTS (
      SELECT 1 FROM policy_acceptances pa
      WHERE pa.policy_id = p.id
      AND pa.user_id = user_uuid
    )
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;