/*
  # Fix role update functionality
  
  1. Changes
    - Drop existing role update triggers and functions
    - Create new function to handle role updates with proper JWT claim updates
    - Add proper session invalidation
    - Ensure atomic updates across all tables
    
  2. Security
    - Maintain admin-only role updates
    - Prevent self-demotion for admins
    - Update JWT claims properly
*/

-- Drop existing triggers and functions
DROP TRIGGER IF EXISTS handle_role_update_trigger ON users;
DROP FUNCTION IF EXISTS handle_role_update();

-- Create improved role update function
CREATE OR REPLACE FUNCTION handle_role_update()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updating_user_role user_role;
BEGIN
  -- Get the role of the user making the update
  SELECT role INTO updating_user_role
  FROM users
  WHERE id = auth.uid();

  -- Check if user is admin
  IF updating_user_role != 'admin' THEN
    RAISE EXCEPTION 'Only administrators can update roles';
  END IF;

  -- Prevent changing own admin role
  IF NEW.id = auth.uid() AND OLD.role = 'admin' AND NEW.role != 'admin' THEN
    RAISE EXCEPTION 'Cannot change your own admin role';
  END IF;

  -- Update auth.users metadata and claims
  UPDATE auth.users
  SET 
    raw_user_meta_data = jsonb_set(
      COALESCE(raw_user_meta_data, '{}'::jsonb),
      '{role}',
      to_jsonb(NEW.role::text)
    ),
    raw_app_meta_data = jsonb_set(
      COALESCE(raw_app_meta_data, '{}'::jsonb),
      '{role}',
      to_jsonb(NEW.role::text)
    ),
    updated_at = now()
  WHERE id = NEW.id;

  -- Delete all sessions for the user to force re-login with new role
  DELETE FROM auth.sessions
  WHERE user_id = NEW.id;

  -- Reset the last_sign_in_at to force token refresh
  UPDATE auth.users
  SET last_sign_in_at = NULL
  WHERE id = NEW.id;

  -- Update the role in the users table
  NEW.updated_at = now();
  
  RETURN NEW;
END;
$$;

-- Create trigger for role updates
CREATE TRIGGER handle_role_update_trigger
  BEFORE UPDATE OF role
  ON users
  FOR EACH ROW
  EXECUTE FUNCTION handle_role_update();

-- Ensure RLS policy exists for role updates
DROP POLICY IF EXISTS "Enable role updates for admins" ON users;
CREATE POLICY "Enable role updates for admins"
  ON users
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  );

-- Grant necessary permissions
GRANT UPDATE ON users TO authenticated;