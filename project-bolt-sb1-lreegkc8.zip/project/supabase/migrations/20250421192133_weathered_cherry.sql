/*
  # Add PDF support for company policy

  1. Changes
    - Add policy_pdf_url column to store PDF URL
    - Add policy_updated_at column to track updates
    - Add policy_updated_by column to track who updated it
*/

-- Add policy_pdf_url column
ALTER TABLE users
ADD COLUMN policy_pdf_url TEXT,
ADD COLUMN policy_updated_at TIMESTAMPTZ DEFAULT now(),
ADD COLUMN policy_updated_by UUID REFERENCES users(id);

-- Create policy to allow admins to update policy PDF
CREATE POLICY "Only admins can update policy PDF"
ON storage.objects
FOR ALL 
TO authenticated
USING (
  bucket_id = 'policy-docs' AND
  EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.role = 'admin'
  )
);