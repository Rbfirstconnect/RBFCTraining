/*
  # Fix role update synchronization
  
  1. Changes
    - Drop existing triggers and functions
    - Create new function to properly sync roles
    - Add proper error handling and validation
    - Ensure atomic updates
    
  2. Security
    - Maintain admin-only role updates
    - Prevent self-demotion for admins
*/

-- Drop existing triggers and functions
DROP TRIGGER IF EXISTS validate_role_update_trigger ON users;
DROP TRIGGER IF EXISTS on_user_role_updated ON users;
DROP FUNCTION IF EXISTS validate_role_update();
DROP FUNCTION IF EXISTS sync_user_role();

-- Create function to handle role updates and sync
CREATE OR REPLACE FUNCTION handle_role_update()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updating_user_role user_role;
BEGIN
  -- Get the role of the user making the update
  SELECT role INTO updating_user_role
  FROM users
  WHERE id = auth.uid();

  -- Check if user is admin
  IF updating_user_role != 'admin' THEN
    RAISE EXCEPTION 'Only administrators can update roles';
  END IF;

  -- Prevent changing own admin role
  IF NEW.id = auth.uid() AND OLD.role = 'admin' AND NEW.role != 'admin' THEN
    RAISE EXCEPTION 'Cannot change your own admin role';
  END IF;

  -- Update auth.users metadata in the same transaction
  UPDATE auth.users
  SET raw_user_meta_data = 
    COALESCE(raw_user_meta_data, '{}'::jsonb) || 
    jsonb_build_object('role', NEW.role),
    raw_app_meta_data = 
    COALESCE(raw_app_meta_data, '{}'::jsonb) || 
    jsonb_build_object('role', NEW.role)
  WHERE id = NEW.id;

  -- Update the JWT claim
  PERFORM set_claim(NEW.id, 'role', NEW.role::text);

  RETURN NEW;
END;
$$;

-- Create trigger for role updates
CREATE TRIGGER handle_role_update_trigger
  BEFORE UPDATE OF role
  ON users
  FOR EACH ROW
  EXECUTE FUNCTION handle_role_update();

-- Create policy for admin role updates
DROP POLICY IF EXISTS "Enable role updates for admins" ON users;
CREATE POLICY "Enable role updates for admins"
  ON users
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  );

-- Grant necessary permissions
GRANT UPDATE ON users TO authenticated;