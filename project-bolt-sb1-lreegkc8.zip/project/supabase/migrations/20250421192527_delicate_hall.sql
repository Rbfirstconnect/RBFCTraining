/*
  # Fix policy storage configuration
  
  1. Changes
    - Drop existing policies to avoid conflicts
    - Recreate bucket with proper configuration
    - Add policies for public access and admin management
    
  2. Security
    - Allow public access to read files
    - Restrict management to admin users only
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Allow authenticated users to read policy files" ON storage.objects;
DROP POLICY IF EXISTS "Allow admins to upload policy files" ON storage.objects;
DROP POLICY IF EXISTS "Allow admins to update policy files" ON storage.objects;
DROP POLICY IF EXISTS "Allow admins to delete policy files" ON storage.objects;
DROP POLICY IF EXISTS "Only admins can update policy PDF" ON storage.objects;
DROP POLICY IF EXISTS "Allow public read access" ON storage.objects;

-- Ensure bucket exists and is public
INSERT INTO storage.buckets (id, name, public)
VALUES ('policy-docs', 'policy-docs', true)
ON CONFLICT (id) DO UPDATE
SET public = true;

-- Allow public access to read files
CREATE POLICY "Allow public access to policy files"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'policy-docs');

-- Allow admins to manage files
CREATE POLICY "Allow admins to manage policy files"
ON storage.objects FOR ALL
TO authenticated
USING (
  bucket_id = 'policy-docs'
  AND EXISTS (
    SELECT 1 FROM public.users
    WHERE users.id = auth.uid()
    AND users.role = 'admin'
  )
)
WITH CHECK (
  bucket_id = 'policy-docs'
  AND EXISTS (
    SELECT 1 FROM public.users
    WHERE users.id = auth.uid()
    AND users.role = 'admin'
  )
);