/*
  # Add policy management functions

  1. New Functions
    - `check_and_update_policy_status`: Automatically checks and updates user's policy status
    - `get_pending_policies`: Gets list of policies user hasn't accepted yet
    
  2. Security
    - Functions are security definer
    - Access restricted to authenticated users
*/

-- Function to check and update policy status
CREATE OR REPLACE FUNCTION check_and_update_policy_status(user_uuid UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  all_accepted BOOLEAN;
BEGIN
  -- Check if all active policies are accepted
  SELECT NOT EXISTS (
    SELECT 1 FROM policies p
    WHERE p.is_active = true
    AND NOT EXISTS (
      SELECT 1 FROM policy_acceptances pa
      WHERE pa.policy_id = p.id
      AND pa.user_id = user_uuid
    )
  ) INTO all_accepted;

  -- Update user's policy_accepted status
  UPDATE users
  SET 
    policy_accepted = all_accepted,
    policy_updated_at = NOW()
  WHERE id = user_uuid;

  RETURN all_accepted;
END;
$$;

-- Function to get pending policies for a user
CREATE OR REPLACE FUNCTION get_pending_policies(user_uuid UUID)
RETURNS TABLE (
  id UUID,
  title TEXT,
  description TEXT,
  pdf_url TEXT,
  created_at TIMESTAMPTZ,
  display_order INTEGER
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.title,
    p.description,
    p.pdf_url,
    p.created_at,
    p.display_order
  FROM policies p
  WHERE p.is_active = true
  AND NOT EXISTS (
    SELECT 1 FROM policy_acceptances pa
    WHERE pa.policy_id = p.id
    AND pa.user_id = user_uuid
  )
  ORDER BY p.display_order;
END;
$$;

-- Grant execute permissions to authenticated users
GRANT EXECUTE ON FUNCTION check_and_update_policy_status TO authenticated;
GRANT EXECUTE ON FUNCTION get_pending_policies TO authenticated;