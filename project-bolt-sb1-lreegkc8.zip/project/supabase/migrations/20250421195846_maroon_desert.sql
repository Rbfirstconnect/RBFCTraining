/*
  # Fix policy acceptance order handling

  1. Changes
    - Add function to validate policy acceptance order
    - Update check_and_update_policy_status to enforce order
    - Add helper function to get next required policy
*/

-- Function to get the next required policy for a user
CREATE OR REPLACE FUNCTION get_next_required_policy(user_uuid UUID)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  next_policy_id UUID;
BEGIN
  -- Get the first unaccepted policy with the lowest display_order
  SELECT p.id INTO next_policy_id
  FROM policies p
  WHERE p.is_active = true
  AND NOT EXISTS (
    SELECT 1 FROM policy_acceptances pa
    WHERE pa.policy_id = p.id
    AND pa.user_id = user_uuid
  )
  ORDER BY p.display_order
  LIMIT 1;

  RETURN next_policy_id;
END;
$$;

-- Function to validate policy acceptance order
CREATE OR REPLACE FUNCTION validate_policy_acceptance(user_uuid UUID, policy_uuid UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_policy_order INTEGER;
  last_accepted_order INTEGER;
BEGIN
  -- Get the order of the policy being accepted
  SELECT display_order INTO current_policy_order
  FROM policies
  WHERE id = policy_uuid;

  -- Get the highest order of previously accepted policies
  SELECT COALESCE(MAX(p.display_order), -1) INTO last_accepted_order
  FROM policy_acceptances pa
  JOIN policies p ON p.id = pa.policy_id
  WHERE pa.user_id = user_uuid;

  -- Policy can only be accepted if it's the next in order
  RETURN current_policy_order = last_accepted_order + 1;
END;
$$;

-- Update the check_and_update_policy_status function to enforce order
CREATE OR REPLACE FUNCTION check_and_update_policy_status(user_uuid UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  all_accepted BOOLEAN;
  next_required UUID;
BEGIN
  -- Check if all active policies are accepted in order
  SELECT NOT EXISTS (
    SELECT 1 FROM policies p
    WHERE p.is_active = true
    AND NOT EXISTS (
      SELECT 1 FROM policy_acceptances pa
      WHERE pa.policy_id = p.id
      AND pa.user_id = user_uuid
    )
  ) INTO all_accepted;

  -- Update user's policy_accepted status
  IF all_accepted THEN
    UPDATE users
    SET 
      policy_accepted = true,
      policy_updated_at = NOW()
    WHERE id = user_uuid;
  END IF;

  RETURN all_accepted;
END;
$$;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION get_next_required_policy TO authenticated;
GRANT EXECUTE ON FUNCTION validate_policy_acceptance TO authenticated;
GRANT EXECUTE ON FUNCTION check_and_update_policy_status TO authenticated;