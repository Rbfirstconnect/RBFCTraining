/*
  # Add role update policies and functions
  
  1. Changes
    - Add policy to allow admins to update user roles
    - Add function to validate role updates
    - Add trigger to enforce role update rules
    
  2. Security
    - Only admins can update roles
    - Cannot change own admin role
    - Maintain role hierarchy
*/

-- Create function to validate role updates
CREATE OR REPLACE FUNCTION validate_role_update()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Check if user is admin
  IF NOT EXISTS (
    SELECT 1 FROM users
    WHERE id = auth.uid()
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Only administrators can update roles';
  END IF;

  -- Prevent changing own admin role
  IF NEW.id = auth.uid() AND OLD.role = 'admin' AND NEW.role != 'admin' THEN
    RAISE EXCEPTION 'Cannot change your own admin role';
  END IF;

  RETURN NEW;
END;
$$;

-- Create trigger for role updates
DROP TRIGGER IF EXISTS validate_role_update_trigger ON users;
CREATE TRIGGER validate_role_update_trigger
  BEFORE UPDATE OF role
  ON users
  FOR EACH ROW
  EXECUTE FUNCTION validate_role_update();

-- Drop existing policies
DROP POLICY IF EXISTS "Enable update for admins and own profile" ON users;

-- Create new policy for role updates
CREATE POLICY "Enable role updates for admins"
  ON users
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  );