/*
  # Add HR training completion tracking
  
  1. Changes
    - Add hr_training_completed column to users table
    - Set default value to false
    - Update existing users to false to require completion
*/

-- Add hr_training_completed column
ALTER TABLE users
ADD COLUMN hr_training_completed BOOLEAN DEFAULT false;

-- Set existing users to false to require completion
UPDATE users
SET hr_training_completed = false
WHERE hr_training_completed IS NULL;