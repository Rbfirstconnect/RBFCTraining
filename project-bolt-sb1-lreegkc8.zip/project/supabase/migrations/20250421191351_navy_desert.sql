/*
  # Add policy acceptance tracking
  
  1. Changes
    - Add policy_accepted column to users table
    - Set default value to false
    - Update existing users to have policy_accepted = true
    
  2. Security
    - Maintain existing RLS policies
*/

-- Add policy_accepted column to users table
ALTER TABLE users
ADD COLUMN policy_accepted BOOLEAN DEFAULT false;

-- Set existing users to have accepted the policy
UPDATE users
SET policy_accepted = true
WHERE policy_accepted IS NULL;