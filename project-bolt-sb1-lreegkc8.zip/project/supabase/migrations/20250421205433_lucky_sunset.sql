/*
  # Fix HR training completion tracking

  1. Changes
    - Add NOT NULL constraint to hr_training_completed
    - Add function to update HR training status
    - Add trigger to track training completion
*/

-- Ensure hr_training_completed has proper constraints
ALTER TABLE users
ALTER COLUMN hr_training_completed SET DEFAULT false,
ALTER COLUMN hr_training_completed SET NOT NULL;

-- Create function to update HR training status
CREATE OR REPLACE FUNCTION update_hr_training_status(user_uuid UUID, completed BOOLEAN)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE users
  SET hr_training_completed = completed
  WHERE id = user_uuid;
  
  RETURN FOUND;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION update_hr_training_status TO authenticated;