/*
  # Create policy documents storage bucket

  1. Storage Changes
    - Create 'policy-docs' bucket for storing company policy PDFs
    - Set up public access for reading policy documents
    - Restrict upload permissions to admin users only

  2. Security
    - Enable public read access to allow all authenticated users to view policies
    - Restrict write/delete access to admin users only
*/

-- Create the storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('policy-docs', 'policy-docs', true);

-- Allow public access to read files (authenticated users only)
CREATE POLICY "Allow public read access"
ON storage.objects
FOR SELECT
TO authenticated
USING (bucket_id = 'policy-docs');

-- Allow admin users to upload files
CREATE POLICY "Allow admin users to upload files"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'policy-docs'
  AND (
    SELECT role = 'admin'
    FROM auth.users
    WHERE auth.users.id = auth.uid()
  )
);

-- Allow admin users to update files
CREATE POLICY "Allow admin users to update files"
ON storage.objects
FOR UPDATE
TO authenticated
USING (
  bucket_id = 'policy-docs'
  AND (
    SELECT role = 'admin'
    FROM auth.users
    WHERE auth.users.id = auth.uid()
  )
)
WITH CHECK (
  bucket_id = 'policy-docs'
  AND (
    SELECT role = 'admin'
    FROM auth.users
    WHERE auth.users.id = auth.uid()
  )
);

-- Allow admin users to delete files
CREATE POLICY "Allow admin users to delete files"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'policy-docs'
  AND (
    SELECT role = 'admin'
    FROM auth.users
    WHERE auth.users.id = auth.uid()
  )
);