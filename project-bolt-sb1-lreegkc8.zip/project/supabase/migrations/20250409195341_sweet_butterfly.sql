/*
  # Add RB logo to storage

  1. Changes
    - Create a function to ensure the RB logo exists in storage
    - Add policy to allow public access to the logo
*/

-- Function to ensure RB logo exists
CREATE OR REPLACE FUNCTION ensure_rb_logo()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Ensure the bucket exists
  INSERT INTO storage.buckets (id, name, public)
  VALUES ('training-images', 'training-images', true)
  ON CONFLICT (id) DO NOTHING;

  -- Add policy for public access to logo
  CREATE POLICY "Public access to RB logo"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'training-images' AND name = 'rb-logo.png');
END;
$$;